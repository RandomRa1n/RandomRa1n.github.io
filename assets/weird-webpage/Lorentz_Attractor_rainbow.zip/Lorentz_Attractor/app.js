let scene, camera, renderer, particle;
let line, lineGeometry, drawCount;
let x = 0.01, y = 0.01, z = 0.01; // 初始位置
// 随机生成洛伦兹吸引子的参数
let sigma = Math.random() * 10 + 10; // 随机生成 10 到 20 之间的值
let rho = Math.random() * 20 + 20;   // 随机生成 20 到 40 之间的值
let beta = Math.random() * 2 + 2;    // 随机生成 2 到 4 之间的值
let dt = 0.01; // 时间步长
let maxPoints = 10000; // 轨迹的最大顶点数
// 初始化时创建颜色数组
let colors = new Float32Array(maxPoints * 3); // 每个点3个颜色分量（RGB）

function init() {
    // 创建场景
    scene = new THREE.Scene();

    // 创建摄像机
    camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.set(0, 0, 100); // 根据需要调整摄像机位置

    // 创建渲染器
    renderer = new THREE.WebGLRenderer();
    renderer.setSize(window.innerWidth, window.innerHeight);
    document.body.appendChild(renderer.domElement);

    // 创建粒子
    const particleGeometry = new THREE.SphereGeometry(0.5, 32, 32);
    const particleMaterial = new THREE.MeshBasicMaterial({ color: 0xff0000 });
    particle = new THREE.Mesh(particleGeometry, particleMaterial);
    particle.position.set(0.01, 0.01, 0.01); // 初始位置
    particle.visible = false; // 隐藏粒子
    scene.add(particle);

    drawCount = 0; // 初始化绘制计数

    // 创建轨迹线几何体和材质
    lineGeometry = new THREE.BufferGeometry();
    const positions = new Float32Array(maxPoints * 3); // 3个坐标 * 点数
    lineGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    lineGeometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const lineMaterial = new THREE.LineBasicMaterial({ vertexColors: true });

    line = new THREE.Points(lineGeometry, lineMaterial); // 使用 Points 而不是 Line
    scene.add(line);
    line = new THREE.Line(lineGeometry, lineMaterial);
    scene.add(line);

    animate();
}

function animate() {
    requestAnimationFrame(animate);

    // 更新粒子位置
    dx = sigma * (y - x) * dt;
    dy = (x * (rho - z) - y) * dt;
    dz = (x * y - beta * z) * dt;

    x += dx;
    y += dy;
    z += dz;

    particle.position.set(x, y, z);

    console.log("Particle Position:", particle.position);
    console.log("Speed:", Math.sqrt(dx * dx + dy * dy + dz * dz));

    // 更新轨迹线
    updateLine();

    renderer.render(scene, camera);
}

function updateLine() {
    if (drawCount < maxPoints) {
        let positions = lineGeometry.attributes.position.array;
        let index = drawCount * 3;

        positions[index++] = x;
        positions[index++] = y;
        positions[index] = z;

        // 计算速度并设置颜色
        let speed = Math.sqrt(dx * dx + dy * dy + dz * dz);
        setColor(drawCount, speed);

        drawCount++;
        lineGeometry.attributes.position.needsUpdate = true;
        lineGeometry.attributes.color.needsUpdate = true;
        lineGeometry.setDrawRange(0, drawCount);
    }
}

function setColor(index, speed) {
    // 将速度映射到色相范围，这里假设最大速度为5
    let hue = mapSpeedToHue(speed, 5, 270, 0);
    let hslColor = new THREE.Color(`hsl(${hue}, 100%, 50%)`);

    let colorIndex = index * 3;
    colors[colorIndex] = hslColor.r; // R分量
    colors[colorIndex + 1] = hslColor.g; // G分量
    colors[colorIndex + 2] = hslColor.b; // B分量
}

function mapSpeedToHue(speed, maxSpeed, minHue, maxHue) {
    let normalizedSpeed = Math.min(speed / maxSpeed, 1); // 将速度标准化到0-1之间
    return minHue + (maxHue - minHue) * normalizedSpeed; // 映射到色相范围
}

init();
